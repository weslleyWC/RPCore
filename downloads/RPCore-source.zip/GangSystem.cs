using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using GTA;
using GTA.Math;
using GTA.Native;
using GTA.UI;
using LemonUI;
using LemonUI.Menus;

namespace RPCore
{
    public partial class GangDefinition
    {
        [Newtonsoft.Json.JsonIgnore] public Vector3 Position=>new Vector3(HQX,HQY,HQZ);
    }

    public class GangSystem : ISystem
    {
        public string Name { get { return "gangs"; } }
        readonly ObjectPool pool;
        readonly NativeMenu menu = new NativeMenu("Gangs", "");
        readonly List<GangDefinition> gangs;
        readonly List<Blip> blips = new List<Blip>();
        readonly AchievementSystem ach;
        GangState state;
        bool dirty;NativeItem presenceStatus;
        readonly GangPresence presence=new GangPresence();
        readonly JsonFiles definitions=new JsonFiles();
        string CreatedPath=>System.IO.Path.Combine(Cfg.Dir,"Gangs","RPCoreCreated.json");

        public GangSystem(ObjectPool pool, AchievementSystem ach)
        {
            this.pool = pool; this.ach = ach; pool.Add(menu); Visuals.Register(menu, "gangs");
            gangs = Store.LoadDef("Gangs/CustomGangs.json", () => new List<GangDefinition>()).Where(g => g != null && !string.IsNullOrWhiteSpace(g.Name)).GroupBy(g => g.Name).Select(g => g.First()).ToList();
            gangs.AddRange(Store.LoadDef("Gangs/RPCoreCreated.json", () => new List<GangDefinition>()).Where(g => g != null && !string.IsNullOrWhiteSpace(g.Name) && !gangs.Any(old => old.Name == g.Name)));
            foreach (var gang in gangs)
            {
                var b = MapBlips.Create(gang.Position, "RPCore Gang HQ: " + gang.Name, BlipSprite.GangHighlight, BlipColor.Purple, .75f);
                b.Color = gang.GangColor == "Purple" ? BlipColor.Purple : gang.GangColor == "Green" ? BlipColor.Green : BlipColor.Yellow;
                blips.Add(b);
            }
            ach.Progress += Progress; Reload();
        }

        public void Create(string name)
        {
            if (gangs.Any(g => string.Equals(g.Name, name, StringComparison.OrdinalIgnoreCase))) { Notify.Show("Ja existe uma gangue com este nome."); return; }
            string path = System.IO.Path.Combine(Cfg.Dir, "Gangs", "RPCoreCreated.json");
            var created = definitions.Read(path, () => new List<GangDefinition>());
            if (created.Count >= 50) { Notify.Show("Limite de 50 gangues criadas."); return; }
            var p = Game.Player.Character.Position;
            var gang = new GangDefinition { Name = name, Description = "Gangue criada no RPCore", HQX = p.X, HQY = p.Y, HQZ = p.Z, GangColor = "Purple" };
            created.Add(gang); definitions.Write(path, created); gangs.Add(gang);
            var b = MapBlips.Create(gang.Position, "RPCore Gang HQ: " + name, BlipSprite.GangHighlight, BlipColor.Purple, .75f); blips.Add(b); dirty = true;
            Notify.Show("Gangue cadastrada. F4: HQ e afiliacao.");
        }

        void Progress(string stat, int amount)
        {
            if (stat != "pizza_drops" || string.IsNullOrEmpty(state.Gang) || !gangs.Any(g => g.Name == state.Gang)) return;
            state.Reputation = Math.Min(100, state.Reputation + amount);
            dirty = true;
        }

        void Rebuild()
        {
            menu.Clear(); menu.Name = (state.Gang ?? "Unaffiliated") + " / rep " + state.Reputation;
            var enabled=new NativeItem("Presenca nas HQs: "+(state.PresenceEnabled?"LIGADA":"DESLIGADA"),"Lideres/membros nos postos configurados. Opcional por perfil; no maximo 12 NPCs com limites configuraveis.");
            enabled.Activated+=(s,e)=>{try{var copy=CharacterRules.Copy(state);copy.PresenceEnabled=!copy.PresenceEnabled;Store.Write("GangState.json",copy);state=copy;presence.Clear();dirty=true;}catch(Exception ex){Log.Error("gang presence toggle",ex);Notify.Show("Preferencia nao salva; estado anterior conservado.");}};menu.Add(enabled);
            presenceStatus=new NativeItem("NPCs ativos: "+presence.Count,"Ativacao proxima da HQ; modelo, piso e espaco precisam estar disponiveis. Sem guerras/fiscalizacao nesta etapa.");menu.Add(presenceStatus);
            AddPostAction("Definir posto do lider aqui",true,false);
            AddPostAction("Adicionar posto de membro aqui",false,false);
            AddPostAction("Remover ultimo posto de membro",false,true);
            foreach (var g in gangs)
            {
                var gang = g;
                var route = new NativeItem("GPS: " + gang.Name, (gang.Description ?? "")+" / postos disponiveis: "+presence.Posts(gang));
                route.Activated += (s, e) => { Function.Call(Hash.SET_NEW_WAYPOINT, gang.HQX, gang.HQY); menu.Visible = false; };
                menu.Add(route);
                var join = new NativeItem("Join " + gang.Name, "Visit the HQ on foot. Complete pizza deliveries to earn reputation in RPCore.");
                join.Activated += (s, e) => {
                    var p = Game.Player.Character;
                    if (p.IsDead || p.IsInVehicle() || p.Position.DistanceTo(gang.Position) > 5) { Notify.Show("Visit the gang HQ on foot to join."); return; }
                    if (state.Gang == gang.Name) return;
                    state.Gang = gang.Name; state.Reputation = 0; Save(); dirty = true;
                    Notify.Show("Joined " + gang.Name);
                };
                menu.Add(join);
            }
            var leave = new NativeItem("Leave current gang");
            leave.Activated += (s, e) => { state.Gang = null; state.Reputation = 0; Save(); dirty = true; }; menu.Add(leave);
            dirty = false;
        }

        void AddPostAction(string label,bool leader,bool remove)
        {
            var item=new NativeItem(label,"Somente sua gangue criada no RPCoreCreated.json. A pe a ate 70m da HQ, sem combate/procurado/missao. Postos a pelo menos 2m; limite 20. Modelos existentes preservados.");
            item.Activated+=(s,e)=>{try{
                var p=Game.Player.Character;
                if(p.IsDead || p.IsInVehicle() || p.IsInCombat || Game.IsMissionActive || Game.Player.Wanted.WantedLevel>0 || InterfaceOptions.ModalOpen || Function.Call<bool>(Hash.IS_CUTSCENE_ACTIVE)){Notify.Show("Configure a pe, em seguranca.");return;}
                var source=definitions.Read(CreatedPath,()=>new List<GangDefinition>());
                var own=source.Find(g=>g!=null && string.Equals(g.Name,state.Gang,StringComparison.OrdinalIgnoreCase));
                var point=new GangSpot{X=p.Position.X,Y=p.Position.Y,Z=p.Position.Z,Heading=p.Heading};
                if(own==null || !GangPresenceRules.AtHQ(own,point)){Notify.Show("Filiacao a uma gangue criada por voce e proximidade da HQ necessarias.");return;}
                var next=GangPresenceRules.Edit(source,state.Gang,point,leader,remove);
                if(next==null){Notify.Show("Posto muito proximo, limite atingido ou nada para remover.");return;}
                definitions.Write(CreatedPath,next);var replacement=next.Find(g=>g!=null && string.Equals(g.Name,state.Gang,StringComparison.OrdinalIgnoreCase));
                int index=gangs.FindIndex(g=>string.Equals(g.Name,state.Gang,StringComparison.OrdinalIgnoreCase));if(index>=0)gangs[index]=replacement;
                presence.Clear();dirty=true;Notify.Show("Postos salvos. Afaste-se alguns metros para liberar o spawn.");
            }catch(Exception ex){Log.Error("gang post edit",ex);Notify.Show("Postos nao alterados; confira arquivo e backup.");}};menu.Add(item);
        }

        public void Tick()
        {
            try{presence.Tick(gangs,state.PresenceEnabled);}catch(Exception ex){presence.Clear();Log.Error("gang presence",ex);}
            if (menu.Visible && dirty) Rebuild();
            if(menu.Visible && presenceStatus!=null)presenceStatus.Title="NPCs ativos: "+presence.Count;
            var p = Game.Player.Character;
            if (p.IsDead) return;
            foreach (var g in gangs.Where(g => p.Position.DistanceTo(g.Position) < 35))
                World.DrawMarker(MarkerType.Cylinder, g.Position - new Vector3(0, 0, 1), Vector3.Zero, Vector3.Zero, new Vector3(2, 2, 1), Color.FromArgb(90, 160, 80, 220));
        }
        public void OnKey(KeyEventArgs e)
        {
            if (e.KeyCode != Cfg.GangsKey) return;
            if (menu.Visible) menu.Visible = false;
            else if (!pool.AreAnyVisible) { Rebuild(); menu.Visible = true; }
        }
        public void Reload() { presence.Clear();dirty=true;state = Store.Load("GangState.json", () => new GangState()); state.Reputation = Math.Max(0, Math.Min(100, state.Reputation)); menu.Visible = false; }
        public void Save() { Store.Write("GangState.json", state); }
        public void Dispose() { presence.Dispose();ach.Progress -= Progress; menu.Visible = false; foreach (var b in blips) if (b.Exists()) b.Delete(); }
    }
}
