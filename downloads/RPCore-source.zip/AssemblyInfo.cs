using System.Reflection;

[assembly: AssemblyVersion("0.21.0.0")]
[assembly: AssemblyFileVersion("0.21.0.0")]
[assembly: AssemblyInformationalVersion("0.21.0-pdm-staff-phase6c")]
