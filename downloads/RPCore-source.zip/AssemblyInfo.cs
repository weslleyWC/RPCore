using System.Reflection;

[assembly: AssemblyVersion("0.49.0.0")]
[assembly: AssemblyFileVersion("0.49.0.0")]
[assembly: AssemblyInformationalVersion("0.49.0-gang-defense-phase6-5g")]
