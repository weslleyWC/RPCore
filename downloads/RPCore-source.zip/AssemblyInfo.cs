using System.Reflection;

[assembly: AssemblyVersion("0.25.0.0")]
[assembly: AssemblyFileVersion("0.25.0.0")]
[assembly: AssemblyInformationalVersion("0.25.0-pdm-rental-orders-phase6g")]
