using System.Reflection;

[assembly: AssemblyVersion("0.36.0.0")]
[assembly: AssemblyFileVersion("0.36.0.0")]
[assembly: AssemblyInformationalVersion("0.36.0-cosmetics-phase6-3c")]
