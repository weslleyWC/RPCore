using System;
using System.Collections.Generic;
using System.Linq;
using GTA;
using GTA.Math;
using GTA.Native;
using LemonUI;
using LemonUI.Menus;

namespace RPCore
{
    internal sealed class GangBusiness
    {
        const string OwnerKey="gang_business";
        readonly ShiftGate gate; readonly ObjectPool pool; readonly Func<GangState> state;
        readonly Func<IEnumerable<GangDefinition>> gangs; readonly GangTurfOptions territories;
        readonly GangBusinessOptions options; readonly NativeMenu menu;readonly GangSupply supply;readonly GangLaundering laundering;readonly GangWarehouse warehouse;readonly GangRaid raid;readonly GangBulk bulk;readonly GangWeaponRaid weaponRaid;readonly GangAutoArms autoArms;readonly GangAutoLaunder autoLaunder;readonly GangPromotion promotion;readonly GangMechanic mechanic;readonly GangTow tow;readonly GangCashRun cashRun;readonly GangMedical medical;readonly GangPopUp popUp;readonly GangMowing mowing;readonly GangTheatre theatre;readonly GangChauffeur chauffeur;readonly GangDock dock;readonly GangBmx bmx;
        public void ConfigureDealer(DealerJob dealer){laundering.Dealer=dealer;warehouse.Dealer=dealer;supply.Dealer=dealer;raid.Dealer=dealer;bulk.Dealer=dealer;}
        GangBusinessService service; GangTurfDefinition area; string profile,gang,id; int player;
        public string SuspensionMessage=>bmx.Active?"BMX suspensa. Checkpoints e tempo salvos; F4 retoma ou cancela.":dock.Active?"Frete do porto suspenso. Carga/descarga, tempo e danos salvos; F4 retoma ou cancela.":chauffeur.Active?"Corrida VIP suspensa. Nota e tempo salvos; F4 retoma ou cancela.":theatre.Active?"Montagem da estreia suspensa. Coletas e instalacoes salvas; F4 retoma ou cancela.":mowing.Active?"Jardinagem suspensa. Cortes salvos; saia do cortador e retome no ponto inicial pelo F4.":popUp.Active?"Loja temporaria suspensa. Vendas e receita confirmadas salvas; F4 retoma ou cancela.":medical.Active?"Entrega medica suspensa. Coleta/entrega salvas; F4 retoma ou cancela.":cashRun.Active?"Transporte de valores suspenso. Contrato salvo; F4 retoma ou cancela.":tow.Active?"Guincho suspenso. Entregas salvas; saia do veiculo e retome no patio pelo F4.":mechanic.Active?"Oficina suspensa. Reparos salvos; F4 retoma ou cancela.":promotion.Active?"Divulgacao suspensa. Contrato salvo; F4 retoma ou cancela.":weaponRaid.Active?"Roubo de van suspenso. F4 > Comercio: retomar ou cancelar.":bulk.Active?"Venda em lote suspensa. F4 > Comercio: retomar ou cancelar contrato.":raid.Active?"Roubo suspenso. F4 > Comercio: retomar ou cancelar contrato.":supply.Active?"Abastecimento suspenso. Contrato salvo; F4 retoma ou cancela.":laundering.Active?"Processamento suspenso; receita nao consumida. Reinicie pelo F4.":"Atendimento encerrado; nenhum estoque nao confirmado foi consumido.";
        public bool Active=>bmx.Active || dock.Active || chauffeur.Active || theatre.Active || mowing.Active || popUp.Active || medical.Active || cashRun.Active || tow.Active || mechanic.Active || promotion.Active || service!=null || supply.Active || laundering.Active || raid.Active || bulk.Active || weaponRaid.Active;
        static Vector3 Pos(GangTurfDefinition a)=>new Vector3(a.Center.X,a.Center.Y,a.Center.Z);
        public GangBusiness(ShiftGate gate,ObjectPool pool,Func<GangState> state,Func<IEnumerable<GangDefinition>> gangs)
        {
            this.gate=gate;this.pool=pool;this.state=state;this.gangs=gangs;
            territories=Store.LoadDef("Gangs/Territories.json",GangTurfOptions.Defaults);
            if(territories==null || !territories.Valid)territories=GangTurfOptions.Defaults();
            options=Store.LoadDef("Gangs/Business.json",()=>new GangBusinessOptions());
            if(options==null || !options.Valid){options=new GangBusinessOptions();Log.Write("Invalid gang business config; original retained, defaults used.");}
            laundering=new GangLaundering(gate,pool,state,gangs);
            supply=new GangSupply(gate,pool,state,gangs,()=>territories.Areas,options);
            warehouse=new GangWarehouse(gate,pool,state,gangs,supply);
            raid=new GangRaid(gate,pool,state,gangs,()=>territories.Areas);
            weaponRaid=new GangWeaponRaid(gate,pool,state,gangs,()=>territories.Areas);
            bmx=new GangBmx(gate,pool,state,gangs,()=>territories.Areas);
            dock=new GangDock(gate,pool,state,gangs,()=>territories.Areas);
            chauffeur=new GangChauffeur(gate,pool,state,gangs,()=>territories.Areas);
            theatre=new GangTheatre(gate,pool,state,gangs,()=>territories.Areas);
            mowing=new GangMowing(gate,pool,state,gangs,()=>territories.Areas);
            popUp=new GangPopUp(gate,pool,state,gangs,()=>territories.Areas);
            medical=new GangMedical(gate,pool,state,gangs,()=>territories.Areas);
            cashRun=new GangCashRun(gate,pool,state,gangs,()=>territories.Areas);
            tow=new GangTow(gate,pool,state,gangs,()=>territories.Areas);
            mechanic=new GangMechanic(gate,pool,state,gangs,()=>territories.Areas);
            promotion=new GangPromotion(gate,pool,state,gangs,()=>territories.Areas);
            autoLaunder=new GangAutoLaunder(gate,pool,state,gangs,()=>territories.Areas);
            autoArms=new GangAutoArms(gate,pool,state,gangs,()=>territories.Areas);
            bulk=new GangBulk(gate,pool,state,gangs,()=>territories.Areas,autoArms);
            menu=new NativeMenu("Comercio territorial","ESTOQUE / ATENDIMENTO / RECEITA");pool.Add(menu);Visuals.Register(menu,"gangs");
        }
        bool Safe(GangTurfDefinition a)
        {
            var p=Game.Player.Character;var s=state();
            return GangBusinessTransactions.Owns(s,a) && gangs().Any(g=>GangCrewRules.SameGang(g.Name,s.Gang)) && p.IsHuman && !p.IsDead && p.IsOnFoot && !p.IsInCombat && Game.Player.Wanted.WantedLevel==0 && !Game.IsMissionActive && !Function.Call<bool>(Hash.IS_CUTSCENE_ACTIVE) && p.Position.DistanceTo(Pos(a))<=options.Radius;
        }
        void Add(string title,string description,Action action=null)
        {
            var row=new NativeItem(title,description);row.Activated+=(s,e)=>{try{action?.Invoke();}catch(Exception ex){Suspend();Log.Error("gang business",ex);Notify.Show("Acao interrompida; confira estoque/pendencia no F4. Falha de gravacao conserva o estado anterior.");}};menu.Add(row);
        }
        public void Open()
        {
            pool.HideAll();menu.Clear();
            if(Wallet.GangBmx!=null && !Wallet.GangBmx.Valid || Wallet.GangDock!=null && !Wallet.GangDock.Valid || Wallet.GangChauffeur!=null && !Wallet.GangChauffeur.Valid || Wallet.GangTheatre!=null && !Wallet.GangTheatre.Valid || Wallet.GangMowing!=null && !Wallet.GangMowing.Valid || Wallet.GangPopUp!=null && !Wallet.GangPopUp.Valid || Wallet.GangMedical!=null && !Wallet.GangMedical.Valid || Wallet.GangCashRun!=null && !Wallet.GangCashRun.Valid || Wallet.GangTow!=null && !Wallet.GangTow.Valid || Wallet.GangMechanic!=null && !Wallet.GangMechanic.Valid || Wallet.GangPromotion!=null && !Wallet.GangPromotion.Valid || Wallet.GangCafe!=null && !Wallet.GangCafe.Valid || Wallet.GangArms!=null && !Wallet.GangArms.Valid || Wallet.GangBulk!=null && !Wallet.GangBulk.Valid || Wallet.GangRaid!=null && !Wallet.GangRaid.Valid || Wallet.GangWarehouse!=null && !Wallet.GangWarehouse.Valid || Wallet.GangIllicit!=null && !Wallet.GangIllicit.Valid || Wallet.GangBusiness!=null && !Wallet.GangBusiness.Valid || Wallet.GangTreasury!=null && !Wallet.GangTreasury.Valid){Add("Dados protegidos","Confira Wallet.json/backup; nenhum estoque ou saldo sera substituido.");menu.Visible=true;return;}
            Add("Banco: $"+Wallet.Bank,"Comercio proprio, presencial. Receita vai ao caixa da gangue; nao ao bolso. Sem vendas offline.");
            bmx.Controls(Add,Open);dock.Controls(Add,Open);chauffeur.Controls(Add,Open);theatre.Controls(Add,Open);mowing.Controls(Add,Open);popUp.Controls(Add,Open);medical.Controls(Add,Open);cashRun.Controls(Add,Open);tow.Controls(Add,Open);mechanic.Controls(Add,Open);promotion.Controls(Add,Open);autoLaunder.Controls(Add,Open);autoArms.Controls(Add,Open);weaponRaid.Controls(Add,Open);bulk.Controls(Add,Open);raid.Controls(Add,Open);supply.Append(Add,Open);laundering.Controls(Add,Open);
            if(service!=null)Add("Encerrar atendimento atual","Tempo nao confirmado e descartado; nenhuma mercadoria e consumida.",()=>{Suspend();Open();});
            var available=territories.Areas.Where(a=>GangBusinessTransactions.Owns(state(),a)).ToList();
            if(available.Count==0)Add("Nenhum territorio disponivel","Filie-se e controle uma area pelo F4 > Territorios. Resolva disputas/iniciacoes pendentes antes de comerciar.");
            foreach(var a in available)
            {
                var target=a;var account=GangBusinessTransactions.Account(Wallet.GangBusiness,state().Gang,a.Id);
                Add(a.Name+" / estoque "+(account?.Stock??0)+"/"+options.Capacity,"Receita historica: $"+(account?.Revenue??0)+". Compra $"+options.UnitCost+"/un; venda $"+options.UnitPrice+"/un.");
                Add("GPS: "+a.Name,"Atendimento a pe, a ate "+options.Radius+"m do ponto do territorio.",()=>{Function.Call(Hash.SET_NEW_WAYPOINT,target.Center.X,target.Center.Y);menu.Visible=false;});
                Add("Repor "+options.PurchaseUnits+" unidades / $"+(options.PurchaseUnits*options.UnitCost),"Debita banco e acrescenta estoque local. Compra direta opcional. O frete abaixo exige buscar e descarregar caixas com desconto.",()=>{if(Active || gate.Owner!=null || !Safe(target) || Game.IsPaused || InterfaceOptions.ModalOpen || !Wallet.GangTrade(state(),target,options,false,GangTreasury.Clock(),Guid.NewGuid().ToString("N"),out _))Notify.Show("Confira posse, proximidade, banco, capacidade e atividade.");Open();});
                Add("Arsenal / armas: "+target.Name,"Compra bancaria de estoque comercial separado, entrega fisica de armas/municao e receita suja. Nao equipa armas pessoais.",()=>bulk.OpenArms(target));
                Add("Venda em lote: "+target.Name,"Escolha produto/quantidade e gangue compradora. Leve a caixa no seu carro; receita suja e chance30% de melhorar relacao ao concluir.",()=>bulk.Open(target));
                weaponRaid.AddStart(target,Add);raid.AddStart(target,Add);
                bmx.Append(target,Add);dock.Append(target,Add);chauffeur.Append(target,Add);theatre.Append(target,Add);mowing.Append(target,Add);popUp.Append(target,Add);medical.Append(target,Add);cashRun.Append(target,Add);tow.Append(target,Add);mechanic.Append(target,Add);promotion.Append(target,Add);supply.AddStart(target,Add);supply.AddCafe(target,Add);
                autoLaunder.Append(target,Add,Open);laundering.Append(target,Add);
                Add("Armazem criminal: "+target.Name,"Guardar/retirar pacotes do trafico e vender do estoque local; separado de mercadorias legais.",()=>warehouse.Open(target));
                Add("Atender "+options.SaleUnits+" unidades / $"+(options.SaleUnits*options.UnitPrice),"Permaneca no local por "+options.ServiceSeconds+"s ativos e confirme E. Pausa/menu nao contam. END cancela sem consumir estoque.",()=>{if(!Begin(target))Notify.Show("Confira estoque, posse, proximidade e atividade.");});
            }
            Add("Fechar","Voltar ao jogo.",()=>menu.Visible=false);menu.Visible=true;
        }
        bool Begin(GangTurfDefinition target)
        {
            if(Active || Wallet.GangBulkBlocked || Wallet.GangRaid?.Pending!=null || Wallet.GangBusiness?.Supply!=null || !Safe(target) || Game.IsPaused || InterfaceOptions.ModalOpen || Wallet.GangBusiness!=null && !Wallet.GangBusiness.Valid || Wallet.GangTreasury!=null && !Wallet.GangTreasury.Valid || (GangBusinessTransactions.Account(Wallet.GangBusiness,state().Gang,target.Id)?.Stock??0)<options.SaleUnits || !gate.Acquire(OwnerKey))return false;
            area=target;profile=Profile.Id;gang=state().Gang;player=Game.Player.Character.Handle;id=Guid.NewGuid().ToString("N");service=new GangBusinessService(Game.GameTime);pool.HideAll();
            Notify.Show("Atendimento iniciado. Permaneça no ponto; E confirma ao terminar, END encerra.");return true;
        }
        bool Current=>service!=null && profile==Profile.Id && player==Game.Player.Character.Handle && GangCrewRules.SameGang(gang,state().Gang) && gate.Owner==OwnerKey && Safe(area);
        public void Tick()
        {
            bmx.Tick();dock.Tick();chauffeur.Tick();theatre.Tick();mowing.Tick();popUp.Tick();medical.Tick();cashRun.Tick();tow.Tick();mechanic.Tick();promotion.Tick();autoArms.Tick();autoLaunder.Tick();weaponRaid.Tick();bulk.Tick();raid.Tick();laundering.Tick();supply.Tick();
            if(service==null)return;
            if(!Current){Suspend();Notify.Show("Atendimento encerrado; estoque e receita nao alterados.");return;}
            bool working=!Game.IsPaused && !pool.AreAnyVisible && !InterfaceOptions.ModalOpen;
            service.Step(Game.GameTime,working);
            if(working){GTA.UI.Screen.ShowSubtitle(area.Name+" / atendimento "+Math.Min(options.ServiceSeconds,service.Milliseconds/1000)+"/"+options.ServiceSeconds+"s / END encerra",100);if(service.Ready(options.ServiceSeconds))GTA.UI.Screen.ShowHelpTextThisFrame("E: confirmar venda e enviar receita para a tesouraria");}
        }
        public void Interact()
        {
            bmx.Interact();dock.Interact();chauffeur.Interact();theatre.Interact();mowing.Interact();popUp.Interact();medical.Interact();cashRun.Interact();tow.Interact();mechanic.Interact();promotion.Interact();weaponRaid.Interact();bulk.Interact();raid.Interact();laundering.Interact();supply.Interact();
            if(!Current || Game.IsPaused || pool.AreAnyVisible || InterfaceOptions.ModalOpen || !service.Ready(options.ServiceSeconds))return;
            if(Wallet.GangTrade(state(),area,options,true,GangTreasury.Clock(),id,out bool changed))
            {Suspend();Notify.Show(changed?"Venda gravada. Receita enviada ao caixa da gangue; confira F4 > Tesouraria.":"Venda ja confirmada; nenhum pagamento repetido.");}
            else{Suspend();Notify.Show("Venda recusada. Confira estoque, posse e limites do caixa; sem debito parcial.");}
        }
        public void Suspend(){bmx.Suspend();dock.Suspend();chauffeur.Suspend();theatre.Suspend();mowing.Suspend();popUp.Suspend();medical.Suspend();cashRun.Suspend();tow.Suspend();mechanic.Suspend();promotion.Suspend();weaponRaid.Suspend();bulk.Suspend();raid.Suspend();laundering.Suspend();supply.Suspend();service=null;area=null;profile=gang=id=null;gate.Release(OwnerKey);}
        public void Dispose(){Close();bmx.Dispose();dock.Dispose();chauffeur.Dispose();theatre.Dispose();mowing.Dispose();cashRun.Dispose();tow.Dispose();mechanic.Dispose();weaponRaid.Dispose();}
        public void Close(){autoLaunder.Clear();autoArms.Clear();bulk.Close();warehouse.Close();Suspend();menu.Visible=false;}
    }
}
