using System.Reflection;

[assembly: AssemblyVersion("0.104.2.0")]
[assembly: AssemblyFileVersion("0.104.2.0")]
[assembly: AssemblyInformationalVersion("0.104.2-prepared-character-ped-handoff")]
