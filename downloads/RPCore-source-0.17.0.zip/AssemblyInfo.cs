using System.Reflection;

[assembly: AssemblyVersion("0.17.0.0")]
[assembly: AssemblyFileVersion("0.17.0.0")]
[assembly: AssemblyInformationalVersion("0.17.0-streamer-phase5e")]
