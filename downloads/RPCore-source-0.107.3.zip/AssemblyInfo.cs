using System.Reflection;

[assembly: AssemblyVersion("0.107.3.0")]
[assembly: AssemblyFileVersion("0.107.3.0")]
[assembly: AssemblyInformationalVersion("0.107.3-pdm-navigation-menu-ownership")]
