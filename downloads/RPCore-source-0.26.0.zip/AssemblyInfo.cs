using System.Reflection;

[assembly: AssemblyVersion("0.26.0.0")]
[assembly: AssemblyFileVersion("0.26.0.0")]
[assembly: AssemblyInformationalVersion("0.26.0-pdm-showroom-phase6h")]
