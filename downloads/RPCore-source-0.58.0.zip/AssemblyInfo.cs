using System.Reflection;

[assembly: AssemblyVersion("0.58.0.0")]
[assembly: AssemblyFileVersion("0.58.0.0")]
[assembly: AssemblyInformationalVersion("0.58.0-gang-bulk-sale-phase6-5p")]
