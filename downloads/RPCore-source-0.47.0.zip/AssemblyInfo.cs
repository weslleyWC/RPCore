using System.Reflection;

[assembly: AssemblyVersion("0.47.0.0")]
[assembly: AssemblyFileVersion("0.47.0.0")]
[assembly: AssemblyInformationalVersion("0.47.0-gang-driving-phase6-5e")]
